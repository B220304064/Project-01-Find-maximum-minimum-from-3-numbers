# maximum-minimum find from 3 number
a=float(input('Enter your first number a:'))
b=float(input('Enter your second number b:'))
c=float(input('Enter your third number c:'))
if(a>b and a>c):
    print("a=",a,"is the maximum number.")
    if(b>c):
        print("c=",c,"is the minimum number.")
    else:
        print("b=",b,"is the minimum number.")
elif(b>a and b>c):
    print("b=",b,"is the maximum number.")
    if(a>c):
        print("c=",c,"is the minimum number.")
    else:
        print("a=",a,"is the minimum number.")
else:
    print("c=",c,"is the maximum number.")    
    if(b>a):
        print("a=",a,"is the minimum number.")
    else:
        print("b=",b,"is the minimum number.")   
        

    
